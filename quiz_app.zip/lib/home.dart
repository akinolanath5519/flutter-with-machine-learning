import 'package:flutter/material.dart';
import 'package:tflite_flutter/tflite_flutter.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  _HomePageState createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  TextEditingController numberController = TextEditingController();
  var result = "Result will be shown here";
  late Interpreter interpreter;

  @override
  void initState() {
    super.initState();
    loadModel();
  }

  loadModel() async {
    interpreter = await Interpreter.fromAsset('assets/linear.tflite');
  }

  void performAction() {
    int x = int.tryParse(numberController.text) ?? 0; // handle parsing error

    var input = [x.toDouble()]; // adjust input format if necessary
    var output = List.filled(1 * 2, 0).reshape([1, 2]);

    interpreter.run(input, output);

    // Displaying output for demonstration
    result = "Result=" + output[0][0].toString();
    setState(() {
      result;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Home"),
      ),
      body: Padding(
        padding: const EdgeInsets.all(20.0),
        child: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: numberController,
                decoration: InputDecoration(hintText: "Type here"),
                keyboardType: TextInputType.number,
              ),
              SizedBox(
                height: 20,
              ),
              ElevatedButton(
                onPressed: performAction,
                child: Text("Predict"),
              ),
              SizedBox(
                height: 20,
              ),
              Text(result),
            ],
          ),
        ),
      ),
    );
  }
}
